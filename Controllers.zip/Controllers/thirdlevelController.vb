﻿Imports System.Web.Mvc

Namespace Controllers
    Public Class thirdlevelController
        Inherits Controller

        ' GET: thirdlevel
        Function thirdlevel() As ActionResult
            Return View("thirdlevel")
        End Function
        Function thirdlevelanswers() As ActionResult
            Return View("thirdlevelanswers")
        End Function
    End Class
End Namespace