﻿Imports System.Web.Mvc
Imports revision.Models
Imports revision.Views.firstlevelquestions
Imports System.Web.UI.WebControls


Namespace Controllers
    Public Class firstlevelController
        Inherits Controller


        Private db As New firstleveldb
        Public Property vbDatabaseCompare As CompareMethod




        ' GET: firstlevel
        Function firstlevel() As ActionResult
            Return View("firstlevel")
        End Function
        Function firstlevelanswers() As ActionResult
            Return View("firstlevelanswers")
        End Function








    End Class
End Namespace