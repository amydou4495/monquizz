﻿Imports System.Web.Mvc

Namespace Controllers
    Public Class secondlevelController
        Inherits Controller

        ' GET: secondlevel
        Function secondlevel() As ActionResult
            Return View("secondlevel")
        End Function
        Function secondlevelanswers() As ActionResult
            Return View("secondlevelanswers")
        End Function
    End Class
End Namespace