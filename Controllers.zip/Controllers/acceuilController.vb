﻿Imports System.Web.Mvc

Namespace Controllers
    Public Class acceuilController
        Inherits Controller

        ' GET: acceuil
        Function acceuil() As ActionResult

            Return View()
        End Function
    End Class
End Namespace