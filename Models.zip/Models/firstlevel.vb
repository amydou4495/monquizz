﻿Imports System.Data.Entity
Namespace Models

    Public Class firstlevel
        Public Property ID As Integer
        Public Property question As String
        Public Property choix1 As String
        Public Property choix2 As String
        Public Property choix3 As String
        Public Property canswer As Decimal
    End Class
    Public Class firstleveldb
        Inherits DbContext
        Public Property firstlevel As DbSet(Of firstlevel)

    End Class
End Namespace

